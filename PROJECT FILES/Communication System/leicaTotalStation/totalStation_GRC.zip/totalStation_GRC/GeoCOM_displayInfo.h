#ifndef GEOCOM_DISPLAY_INFO_H
#define GEOCOM_DISPLAY_INFO_H

/* This function queries the device for all sorts of information
 */

#include <stdio.h>

void printDeviceInfo(FILE *f);

#endif
